import secrets
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote, urlsplit

HOST = "127.0.0.1"
PORT = 0
CODE_BYTES = 4


class RedirectHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        target = self.server.links.get(self.path.removeprefix("/"))
        if target is None:
            self.send_error(404)
            return

        self.send_response(302)
        self.send_header("Location", target)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()

    do_HEAD = do_GET

    def log_message(self, format, *args):
        pass


class RedirectServer(ThreadingHTTPServer):
    def __init__(self):
        super().__init__((HOST, PORT), RedirectHandler)
        self.links = {}

    def shorten(self, value):
        target = prepare_url(value.strip())
        code = secrets.token_urlsafe(CODE_BYTES)
        while code in self.links:
            code = secrets.token_urlsafe(CODE_BYTES)
        self.links[code] = target
        return f"http://{HOST}:{self.server_port}/{code}"


def prepare_url(value):
    try:
        parts = urlsplit(value)
        _ = parts.port
        if parts.scheme not in ("http", "https") or not parts.hostname:
            raise ValueError
        if "\\" in parts.netloc or any(c.isspace() or ord(c) < 32 for c in value):
            raise ValueError
    except ValueError:
        raise ValueError("Enter a valid HTTP or HTTPS URL.") from None

    return quote(value, safe=":/?#[]@!$&'()*+,;=%")


def run_window(server):
    import tkinter as tk
    from tkinter import ttk

    window = tk.Tk()
    window.title("GoLink")
    window.minsize(440, 120)
    window.resizable(True, False)
    window.createcommand("tk::mac::Quit", window.destroy)

    panel = ttk.Frame(window, padding=18)
    panel.pack(fill="both", expand=True)
    panel.columnconfigure(0, weight=1)

    url = tk.StringVar()
    result = tk.StringVar()
    status = tk.StringVar()

    def shorten():
        try:
            result.set(server.shorten(url.get()))
        except ValueError as error:
            result.set("")
            copy_button.state(["disabled"])
            status.set(str(error))
            entry.focus_set()
            return
        copy_button.state(["!disabled"])
        status.set("")

    def copy():
        window.clipboard_clear()
        window.clipboard_append(result.get())
        status.set("Copied")

    ttk.Label(panel, text="URL").grid(row=0, column=0, sticky="w")
    entry = ttk.Entry(panel, textvariable=url, width=48)
    entry.grid(row=1, column=0, sticky="ew", pady=(3, 7))
    ttk.Button(panel, text="Shorten", command=shorten).grid(row=1, column=1, padx=(8, 0))
    ttk.Entry(panel, textvariable=result, state="readonly").grid(row=2, column=0, sticky="ew")
    copy_button = ttk.Button(panel, text="Copy", command=copy)
    copy_button.grid(row=2, column=1, padx=(8, 0))
    copy_button.state(["disabled"])
    ttk.Label(panel, textvariable=status).grid(row=3, column=0, sticky="w", pady=(4, 0))

    entry.bind("<Return>", lambda event: shorten())
    entry.focus_set()
    window.mainloop()


def run_cli(server):
    try:
        while value := input("URL: ").strip():
            try:
                print(server.shorten(value))
            except ValueError as error:
                print(error)
    except (EOFError, KeyboardInterrupt):
        print()


def main():
    with RedirectServer() as server:
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        try:
            if "--cli" in sys.argv[1:]:
                run_cli(server)
            else:
                run_window(server)
        finally:
            server.shutdown()
            worker.join()


if __name__ == "__main__":
    main()
