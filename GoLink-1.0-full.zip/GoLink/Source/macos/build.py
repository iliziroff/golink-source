import argparse
import plistlib
import shutil
import struct
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

MACOS = Path(__file__).resolve().parent
PYTHON = Path("/Library/Frameworks/Python.framework/Versions/3.14")
VERSION = "1.0.0"
BUNDLE_ID = "com.iliziroff.golink"


def run(*args):
    subprocess.run(args, check=True)


def make_icon(destination, build):
    records = []
    for kind, pixels in (
        (b"icp4", "16"), (b"icp5", "32"), (b"icp6", "64"),
        (b"ic07", "128"), (b"ic08", "256"), (b"ic09", "512"), (b"ic10", "1024"),
    ):
        image = build / f"icon-{pixels}.png"
        run("sips", "-z", pixels, pixels, MACOS / "logo.png", "--out", image)
        data = image.read_bytes()
        records.append(struct.pack(">4sI", kind, len(data) + 8) + data)
    body = b"".join(records)
    destination.write_bytes(struct.pack(">4sI", b"icns", len(body) + 8) + body)


def make_app(app, python, build):
    contents = app / "Contents"
    macos = contents / "MacOS"
    resources = contents / "Resources"
    frameworks = contents / "Frameworks"
    runtime = resources / "runtime" / "lib" / "python3.14"
    modules = runtime / "lib-dynload"
    for path in (macos, frameworks, modules):
        path.mkdir(parents=True)

    stdlib = python / "lib" / "python3.14"
    shutil.copytree(
        stdlib, runtime, dirs_exist_ok=True,
        ignore=shutil.ignore_patterns(
            "__pycache__", "site-packages", "test", "tests",
            "lib-dynload", "config-*", "ensurepip", "idlelib", "turtledemo",
        ),
    )

    dylib = frameworks / "GoLinkPython.dylib"
    shutil.copy2(python / "Python", dylib)
    run("install_name_tool", "-id", "@rpath/GoLinkPython.dylib", dylib)
    run("codesign", "--force", "--sign", "-", dylib)

    for name in ("Tcl", "Tk"):
        source = python / "Frameworks" / f"{name}.framework" / "Versions" / "8.6"
        framework = frameworks / f"{name}.framework"
        version = framework / "Versions" / "8.6"
        version.mkdir(parents=True)
        shutil.copytree(source / "Resources", version / "Resources")
        shutil.copy2(source / name, version / name)
        (framework / "Versions" / "Current").symlink_to("8.6")
        (framework / "Resources").symlink_to("Versions/Current/Resources")
        (framework / name).symlink_to(f"Versions/Current/{name}")
        run("install_name_tool", "-id", f"@rpath/{name}.framework/{name}", version / name)
        run("codesign", "--force", "--sign", "-", framework)

    module_names = {
        "_bisect", "_heapq", "_hmac", "_opcode", "_posixsubprocess", "_queue",
        "_random", "_scproxy", "_socket", "_struct", "_tkinter", "_typing",
        "array", "binascii", "fcntl", "math", "select", "unicodedata", "zlib",
    }
    for extension in sorted((stdlib / "lib-dynload").glob("*.so")):
        name = extension.name.split(".")[0]
        if name not in module_names:
            continue
        destination = shutil.copy2(extension, modules)
        if name == "_tkinter":
            for library in ("Tcl", "Tk"):
                relative = f"{library}.framework/{library}"
                run(
                    "install_name_tool", "-change", str(python / "Frameworks" / relative),
                    f"@rpath/{relative}", destination,
                )
        run("codesign", "--force", "--sign", "-", destination)

    run(
        "clang", "-arch", "arm64", "-arch", "x86_64", "-mmacosx-version-min=11.0",
        "-Wall", "-O2", "-I", python / "Headers", MACOS / "launcher.c", dylib,
        "-Wl,-rpath,@executable_path/../Frameworks", "-o", macos / "GoLink",
    )
    shutil.copy2(MACOS.parent / "golink.py", resources)
    make_icon(resources / "GoLink.icns", build)
    (contents / "Info.plist").write_bytes(plistlib.dumps({
        "CFBundleName": "GoLink",
        "CFBundleDisplayName": "GoLink",
        "CFBundleIdentifier": BUNDLE_ID,
        "CFBundleExecutable": "GoLink",
        "CFBundleIconFile": "GoLink",
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": VERSION,
        "CFBundleVersion": VERSION,
        "CFBundleDevelopmentRegion": "en",
        "LSMinimumSystemVersion": "11.0",
        "NSHighResolutionCapable": True,
    }))
    run("codesign", "--force", "--sign", "-", app)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--framework", type=Path, default=PYTHON)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    app = output / "GoLink.app"
    if app.exists():
        sys.exit(f"Already exists: {app}")
    if not (args.framework / "Headers" / "Python.h").is_file():
        sys.exit("Install the universal Python 3.14 framework from python.org.")
    with TemporaryDirectory(dir=output) as temporary:
        build = Path(temporary)
        make_app(build / "GoLink.app", args.framework.resolve(), build)
        (build / "GoLink.app").rename(app)


if __name__ == "__main__":
    main()
