on run argv
    set mountPath to item 1 of argv
    set artwork to (POSIX file (mountPath & "/.background/background.png")) as alias
    set volumeFolder to (POSIX file mountPath) as alias
    tell application "Finder"
        open volumeFolder
        set targetWindow to container window of volumeFolder
        set current view of targetWindow to icon view
        set toolbar visible of targetWindow to false
        set statusbar visible of targetWindow to false
        set bounds of targetWindow to {120, 140, 790, 540}
        set options to icon view options of targetWindow
        set arrangement of options to not arranged
        set icon size of options to 128
        set text size of options to 13
        set background picture of options to artwork
        set position of item "GoLink.app" of targetWindow to {175, 171}
        set position of item "Applications" of targetWindow to {495, 171}
        update volumeFolder without registering applications
        delay 1
        close targetWindow
    end tell
end run
