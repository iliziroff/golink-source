#!/bin/bash
set -euo pipefail

if [[ "$#" != 2 ]]; then
    printf '%s\n' 'Usage: bash make_dmg.sh GoLink.app GoLink.dmg' >&2
    exit 2
fi

source_dir="$(cd "$(dirname "$0")" && pwd)"
app="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
output="$(cd "$(dirname "$2")" && pwd)/$(basename "$2")"
temp="$(mktemp -d "${TMPDIR:-/tmp}/golink-dmg.XXXXXX")"
mount="$temp/mount"
device=""

cleanup() {
    if [[ -n "$device" ]]; then
        hdiutil detach "$device" || return
    fi
    rm -rf "$temp"
}
trap cleanup EXIT

if [[ -e "$output" ]]; then
    printf 'Already exists: %s\n' "$output" >&2
    exit 1
fi

mkdir "$mount"
hdiutil create -size 125m -fs HFS+ -volname GoLink "$temp/staging.dmg"
device="$(hdiutil attach "$temp/staging.dmg" -readwrite -noautoopen -mountpoint "$mount" | awk 'NR == 1 {print $1}')"
ditto "$app" "$mount/GoLink.app"
ln -s /Applications "$mount/Applications"
mkdir "$mount/.background"
cp "$source_dir/dmg-background.png" "$mount/.background/background.png"
osascript "$source_dir/layout.applescript" "$mount"
sync
hdiutil detach "$device"
device=""
hdiutil convert "$temp/staging.dmg" -format UDZO -imagekey zlib-level=9 -o "$output"
