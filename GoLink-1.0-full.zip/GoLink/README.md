# GoLink

Русский · English · العربية · 简体中文

## Русский

**Установка.** Распакуй архив, открой `GoLink.dmg` и перетащи **GoLink** в **Applications** («Программы»). Запусти GoLink из этой папки. Python уже входит в приложение. Сборка рассчитана на macOS 11 и новее, Apple Silicon и Intel. Сборка подписана локальной подписью и не нотарифицирована Apple.

**Использование.** Вставь полный адрес с `https://` или `http://`, нажми **Shorten** или Enter, затем **Copy**. Ссылка открывается на том же Mac и действует, пока GoLink запущен. При выходе из приложения все ссылки удаляются.

**Что менять.**

- `Source/golink.py` → `HOST` — адрес локального сервера, по умолчанию `127.0.0.1`. `PORT` — порт, при `0` macOS выбирает свободный. `CODE_BYTES` — число случайных байтов в коде ссылки. Значение `4` даёт 6 символов.
- `Source/golink.py` → `run_window()` — подписи кнопок и расположение полей. `prepare_url()` — проверка исходных адресов.
- `Source/macos/` → `logo.png` — квадратная иконка. `dmg-background.png` — фон установщика. `layout.applescript` — размер окна Finder и расположение иконок. `VERSION` и `BUNDLE_ID` в `build.py` — версия и идентификатор.

Из папки `Source` запусти `python3 golink.py` для окна или `python3 golink.py --cli` для терминала. Исходникам нужен Python 3.9+ с Tkinter для окна. Для пересборки установи универсальный Python 3.14 с python.org и Xcode Command Line Tools. Выполни `python3 macos/build.py build`, затем `bash macos/make_dmg.sh build/GoLink.app build/GoLink.dmg`. При запросе macOS разреши сборке настроить окно Finder.

## English

**Install.** Extract the ZIP, open `GoLink.dmg`, and drag **GoLink** into **Applications**. Open GoLink from that folder. Python is bundled. The build targets macOS 11 or later on Apple Silicon and Intel. It uses an ad-hoc signature and has no Apple notarization.

**Use.** Paste a full `https://` or `http://` URL, click **Shorten** or press Enter, then click **Copy**. The link opens on the same Mac while GoLink is running. Quitting the app deletes all links.

**Customize.**

- In `Source/golink.py`, `HOST` is the local server address and defaults to `127.0.0.1`. `PORT` sets the port. Use `0` to let macOS choose a free port. `CODE_BYTES` sets the number of random bytes in each code. The default of `4` produces six characters.
- In `Source/golink.py`, edit `run_window()` for button labels and field layout, or `prepare_url()` for input validation.
- In `Source/macos/`, replace `logo.png` for the square icon or `dmg-background.png` for the installer background. Edit `layout.applescript` for the Finder window size and icon positions. Edit `VERSION` and `BUNDLE_ID` in `build.py` for the version and bundle identifier.

From `Source`, run `python3 golink.py` for the window or `python3 golink.py --cli` for the terminal. The source needs Python 3.9+ and the window requires Tkinter. To rebuild, install universal Python 3.14 from python.org and Xcode Command Line Tools. Run `python3 macos/build.py build`, then `bash macos/make_dmg.sh build/GoLink.app build/GoLink.dmg`. If macOS prompts, allow the build to configure the Finder window.

## العربية

**التثبيت.** فكّ ضغط الأرشيف وافتح `GoLink.dmg`، ثم اسحب **GoLink** إلى مجلد **Applications** (التطبيقات). افتح GoLink من هذا المجلد. يأتي Python مضمّنًا في التطبيق. تستهدف هذه الحزمة macOS 11 أو أحدث على أجهزة Apple Silicon وIntel. الحزمة موقّعة بتوقيع محلي ولم تخضع للتوثيق من Apple.

**الاستخدام.** ألصق عنوانًا كاملًا يبدأ بـ `https://` أو `http://`، ثم انقر على **Shorten** أو اضغط Enter، وبعدها انقر على **Copy**. يعمل الرابط على جهاز Mac نفسه ما دام GoLink قيد التشغيل. تُحذف جميع الروابط عند إنهاء التطبيق.

**التخصيص.**

- في `Source/golink.py`، يحدّد `HOST` عنوان الخادم المحلي وقيمته الافتراضية `127.0.0.1`. يحدّد `PORT` المنفذ، وتتيح القيمة `0` لنظام macOS اختيار منفذ متاح. يحدّد `CODE_BYTES` عدد البايتات العشوائية في الرمز، وتعطي القيمة الافتراضية `4` ستة محارف.
- في `Source/golink.py`، عدّل `run_window()` لتغيير أسماء الأزرار وترتيب الحقول، أو `prepare_url()` لتغيير قواعد التحقق من العناوين.
- في `Source/macos/`، استبدل `logo.png` لتغيير الأيقونة المربّعة و`dmg-background.png` لتغيير خلفية التثبيت. عدّل `layout.applescript` لتغيير حجم نافذة Finder ومواضع الأيقونات. يحدّد `VERSION` و`BUNDLE_ID` في `build.py` الإصدار ومعرّف الحزمة.

من مجلد `Source`، نفّذ `python3 golink.py` لفتح النافذة أو `python3 golink.py --cli` للاستخدام في الطرفية. تتطلّب الشيفرة Python 3.9 أو أحدث، وتتطلّب النافذة Tkinter. لإعادة البناء، ثبّت الإصدار العام من Python 3.14 من python.org وأدوات Xcode Command Line Tools. نفّذ `python3 macos/build.py build` ثم `bash macos/make_dmg.sh build/GoLink.app build/GoLink.dmg`. إذا طلب macOS الإذن، اسمح لعملية البناء بإعداد نافذة Finder.

## 简体中文

**安装。** 解压 ZIP，打开 `GoLink.dmg`，将 **GoLink** 拖入 **Applications**（应用程序）文件夹，然后从该文件夹启动 GoLink。应用已内置 Python。此版本面向运行 macOS 11 或更高版本的 Apple 芯片和 Intel 芯片 Mac。应用使用临时签名，未经 Apple 公证。

**使用。** 粘贴以 `https://` 或 `http://` 开头的完整网址，点击 **Shorten** 或按 Enter，再点击 **Copy**。短链接可在同一台 Mac 上打开，并在 GoLink 运行期间有效。退出应用后，所有链接都会被删除。

**自定义。**

- 在 `Source/golink.py` 中，`HOST` 是本地服务器地址，默认值为 `127.0.0.1`。`PORT` 用于设置端口，设为 `0` 时由 macOS 选择可用端口。`CODE_BYTES` 设置短码使用的随机字节数，默认值 `4` 会生成六个字符。
- 在 `Source/golink.py` 中，修改 `run_window()` 可调整按钮文字和输入框布局，修改 `prepare_url()` 可调整网址验证规则。
- 在 `Source/macos/` 中，替换 `logo.png` 可更改方形应用图标，替换 `dmg-background.png` 可更改安装背景。修改 `layout.applescript` 可调整访达窗口大小和图标位置。修改 `build.py` 中的 `VERSION` 和 `BUNDLE_ID` 可更改版本号和应用包标识符。

在 `Source` 文件夹中运行 `python3 golink.py` 可打开窗口，运行 `python3 golink.py --cli` 可在终端使用。运行源码需要 Python 3.9 或更高版本，窗口还需要 Tkinter。重新打包前，请从 python.org 安装通用版 Python 3.14，并安装 Xcode Command Line Tools。先运行 `python3 macos/build.py build`，再运行 `bash macos/make_dmg.sh build/GoLink.app build/GoLink.dmg`。如果 macOS 弹出提示，请允许构建过程设置访达窗口。
